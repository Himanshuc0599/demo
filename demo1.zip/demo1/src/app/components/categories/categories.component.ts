import { Component, OnInit } from "@angular/core";
import { ProductService } from "src/app/service/product.service";

@Component({
  selector: "app-categories",
  templateUrl: "./categories.component.html",
  styleUrls: ["./categories.component.css"],
})
export class CategoriesComponent implements OnInit {
  categories: any;
  constructor(private productService: ProductService) {
    this.getAllcategories();
  }

  ngOnInit(): void {}
  getAllcategories() {
    this.productService.getAllcategories().subscribe(
      (response: any) => {
        this.categories = response;
        console.log(response);
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
}
