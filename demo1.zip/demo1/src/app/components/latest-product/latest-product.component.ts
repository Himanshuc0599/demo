import { Component, OnInit } from "@angular/core";
import { ProductService } from "src/app/service/product.service";

@Component({
  selector: "app-latest-product",
  templateUrl: "./latest-product.component.html",
  styleUrls: ["./latest-product.component.css"],
})
export class LatestProductComponent implements OnInit {
  productDetails: any = [];
  latestProduct: any;
  constructor(private productService: ProductService) {
    this.getAllProductDetails();
    setTimeout(() => {
      let data = this.productDetails;
      let index = Math.floor(Math.random() * data.length);
      this.latestProduct = this.productDetails[index];
      console.log(this.latestProduct, index);
    }, 2000);
  }

  ngOnInit(): void {}
  getAllProductDetails() {
    this.productService.getListProduct().subscribe(
      (response: any) => {
        this.productDetails = response;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
}
