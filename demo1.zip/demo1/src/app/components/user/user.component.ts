import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  userData: any = [];
  constructor(private productService: ProductService) {
    this.getAllUser();
  }

  ngOnInit(): void {}
  getAllUser() {
    this.productService.getAllUser().subscribe(
      (response) => {
        this.userData = response;
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
