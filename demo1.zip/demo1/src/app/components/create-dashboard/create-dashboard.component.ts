import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-dashboard',
  templateUrl: './create-dashboard.component.html',
  styleUrls: ['./create-dashboard.component.css']
})
export class CreateDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
