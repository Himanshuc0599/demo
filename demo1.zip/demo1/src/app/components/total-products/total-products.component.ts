import { Component, OnInit } from "@angular/core";
import { ProductService } from "src/app/service/product.service";

@Component({
  selector: "app-total-products",
  templateUrl: "./total-products.component.html",
  styleUrls: ["./total-products.component.css"],
})
export class TotalProductsComponent implements OnInit {
  productDetails: any = [];
  count!: number;
  constructor(private productService: ProductService) {
    this.getAllProductDetails();
  }

  ngOnInit(): void {}
  getAllProductDetails() {
    this.productService.getListProduct().subscribe(
      (response: any) => {
        this.count = response.length;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
}
