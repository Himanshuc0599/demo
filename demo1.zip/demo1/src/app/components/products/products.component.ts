import { Component, OnInit } from "@angular/core";
import { ProductService } from "src/app/service/product.service";

@Component({
  selector: "app-products",
  templateUrl: "./products.component.html",
  styleUrls: ["./products.component.css"],
})
export class ProductsComponent implements OnInit {
  productDetails: any = [];
  constructor(private productService: ProductService) {
    this.getAllProductDetails();
  }

  ngOnInit(): void {}
  getAllProductDetails() {
    this.productService.getListProduct().subscribe(
      (response: any) => {
        this.productDetails = response;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
}
