import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: "root",
})
export class ProductService {
  constructor(private http: HttpClient) {}

  getListProduct() {
    return this.http.get("https://fakestoreapi.com/products");
  }

  getAllUser() {
    return this.http.get("https://fakestoreapi.com/users");
  }

  getAllcategories() {
    return this.http.get("https://fakestoreapi.com/products/categories");
  }
}
